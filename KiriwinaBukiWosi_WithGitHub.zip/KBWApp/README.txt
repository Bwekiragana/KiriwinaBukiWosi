=========================================================
  KIRIWINA BUKI WOSI — Native Android App
  Build Instructions for Android Studio
=========================================================

WHAT THIS APP INCLUDES
-----------------------
  - Home screen with stats and Song of the Day
  - Search songs by number, lyric line, or author name
  - Full song view with verses + chorus cards
  - Projection / Presentation mode (fullscreen, swipe to advance)
  - Authors list with full biography and story pages
  - Categories browser — tap a category to see all songs in it
  - Church Tools — Wedding vow guide and Dispute resolution steps
  - Maroon + gold theme throughout
  - Bottom navigation bar (native Android app feel)
  - Works on Android 5.0 and above

WHAT YOU NEED
-------------
  - A Windows, Mac, or Linux computer
  - Android Studio (free): https://developer.android.com/studio
  - At least 4 GB free disk space for Android Studio + SDK
  - Internet connection for the first build (downloads libraries)

STEP-BY-STEP BUILD INSTRUCTIONS
---------------------------------

STEP 1 — Download and install Android Studio
  Go to: https://developer.android.com/studio
  Download the installer for your operating system.
  Run it and follow the setup wizard.
  When asked, allow it to install the Android SDK (default options are fine).
  This takes about 10-20 minutes.

STEP 2 — Unzip this project
  Unzip the file "KiriwinaBukiWosi_NativeApp.zip" somewhere easy to find,
  for example your Desktop or Documents folder.

STEP 3 — Open the project in Android Studio
  Open Android Studio.
  On the welcome screen, click "Open" (NOT "New Project").
  Navigate to the unzipped "KiriwinaBukiWosi" folder.
  Click OK / Open.
  Android Studio will load the project. The first time takes 2-5 minutes.

STEP 4 — Let Gradle sync
  You will see a progress bar at the bottom saying "Gradle: Syncing..."
  Wait for it to finish. It needs internet to download the libraries.
  If you see a yellow banner saying "Sync Now" — click it.

STEP 5 — Build the APK
  In the top menu bar click:
    Build → Build Bundle(s) / APK(s) → Build APK(s)
  Wait 2-4 minutes for the build to complete.
  A popup will appear in the bottom-right: "APK(s) generated successfully"
  Click the blue "Locate" link to find the APK file.

  The APK is saved at:
    KiriwinaBukiWosi/app/build/outputs/apk/debug/app-debug.apk

STEP 6 — Transfer the APK to your Android phone
  Option A: USB cable — connect phone to computer, copy the APK file to phone storage
  Option B: WhatsApp — send the APK file to yourself on WhatsApp, then download it
  Option C: Email — email the APK to yourself and open on your phone
  Option D: Google Drive — upload to Drive and download on your phone

STEP 7 — Install on your Android phone
  On your Android phone:
    Go to Settings → Security (or Privacy on some phones)
    Find "Install unknown apps" or "Unknown sources"
    Enable it for the app you are using to open the APK (Files, Chrome, WhatsApp, etc.)
  
  Now open the APK file on your phone and tap "Install".
  The app "Kiriwina Buki Wosi" will appear on your home screen.

HOW TO ADD YOUR REAL SONGS
---------------------------
  Before building, edit this file:
    KiriwinaBukiWosi/app/src/main/assets/songs.json

  It is a JSON file. Each song looks like this:
  {
    "num": 1,
    "title": "Song Title Here",
    "author": "Author Name",
    "category": "Praise",
    "verses": [
      "Verse 1 line 1\nVerse 1 line 2\nVerse 1 line 3",
      "Verse 2 line 1\nVerse 2 line 2\nVerse 2 line 3"
    ],
    "chorus": "Chorus line 1\nChorus line 2"
  }

  If a song has NO chorus, set:  "chorus": null
  Use \n to separate lines within a verse.
  Separate each song with a comma.

HOW TO ADD YOUR REAL AUTHORS
-----------------------------
  Edit this file:
    KiriwinaBukiWosi/app/src/main/assets/authors.json

  Each author looks like this:
  {
    "name": "Full Name",
    "years": "1975-2005",
    "role": "Elder & Choir Director",
    "contribution": "One line summary of contribution",
    "bio": "Full biography paragraph here.",
    "songNums": [1, 5, 12]
  }

AVAILABLE CATEGORIES
--------------------
  Praise, Worship, Prayer, Wedding, Funeral,
  Children, Christmas, Easter, Harvest, General

  To use a category, put the exact name (with capital first letter)
  in the "category" field of each song in songs.json.

TROUBLESHOOTING
---------------
  Problem: "SDK location not found"
  Fix: Open local.properties and set sdk.dir to your SDK path.
       Android Studio usually sets this automatically.

  Problem: Red errors in the code
  Fix: Click File → Invalidate Caches → Restart

  Problem: Gradle sync fails
  Fix: Check your internet connection and try again.
       Go to File → Sync Project with Gradle Files.

  Problem: Cannot install APK on phone
  Fix: Make sure "Install unknown sources" is enabled in phone settings.
       On Android 8+: Settings → Apps → Special app access → Install unknown apps

=========================================================
  App name:     Kiriwina Buki Wosi
  Package name: com.kiriwina.bukiwosi
  Version:      1.0
  Min Android:  5.0 (API 21) and above
  Theme:        Maroon #6B0F1A with Gold #F0C040 accents
=========================================================
