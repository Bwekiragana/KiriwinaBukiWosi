package com.kiriwina.bukiwosi;

import android.content.Context;
import android.view.*;
import android.widget.*;
import java.util.ArrayList;
import java.util.List;

public class SongListAdapter extends BaseAdapter {
    private Context context;
    private List<Song> songs;

    public SongListAdapter(Context context, List<Song> songs) {
        this.context = context;
        this.songs = new ArrayList<>(songs);
    }

    public void updateList(List<Song> newList) {
        songs = new ArrayList<>(newList);
        notifyDataSetChanged();
    }

    @Override public int getCount() { return songs.size(); }
    @Override public Object getItem(int pos) { return songs.get(pos); }
    @Override public long getItemId(int pos) { return pos; }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.item_song, parent, false);
        }
        Song s = songs.get(position);
        TextView tvNum = convertView.findViewById(R.id.tv_song_num);
        TextView tvTitle = convertView.findViewById(R.id.tv_song_title);
        TextView tvMeta = convertView.findViewById(R.id.tv_song_meta);
        TextView tvCat = convertView.findViewById(R.id.tv_song_cat);

        tvNum.setText(String.valueOf(s.num));
        tvTitle.setText(s.title);
        tvMeta.setText(s.author + " • " + s.verses.size() + " verse" + (s.verses.size() > 1 ? "s" : "") + (s.chorus != null ? " + chorus" : ""));
        tvCat.setText(s.category);
        return convertView;
    }
}
