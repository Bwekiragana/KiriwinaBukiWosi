package com.kiriwina.bukiwosi;

import android.content.Intent;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import java.util.List;

public class AuthorDetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_author_detail);

        int index = getIntent().getIntExtra("author_index", 0);
        List<Author> authors = DataManager.getInstance().getAuthors();
        if (index >= authors.size()) { finish(); return; }
        Author author = authors.get(index);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Author");

        TextView tvInitials = findViewById(R.id.tv_initials);
        TextView tvName = findViewById(R.id.tv_name);
        TextView tvRole = findViewById(R.id.tv_role);
        TextView tvYears = findViewById(R.id.tv_years);
        TextView tvContribution = findViewById(R.id.tv_contribution);
        TextView tvBio = findViewById(R.id.tv_bio);
        ChipGroup chipGroup = findViewById(R.id.chip_songs);

        tvInitials.setText(author.getInitials());
        tvName.setText(author.name);
        tvRole.setText(author.role);
        tvYears.setText(author.years);
        tvContribution.setText(author.contribution);
        tvBio.setText(author.bio);

        for (int num : author.songNums) {
            Chip chip = new Chip(this);
            chip.setText("Song " + num);
            chip.setClickable(true);
            final int n = num;
            chip.setOnClickListener(v -> {
                Intent intent = new Intent(this, SongDetailActivity.class);
                intent.putExtra("song_num", n);
                startActivity(intent);
            });
            chipGroup.addView(chip);
        }
    }

    @Override
    public boolean onSupportNavigateUp() { finish(); return true; }
}
