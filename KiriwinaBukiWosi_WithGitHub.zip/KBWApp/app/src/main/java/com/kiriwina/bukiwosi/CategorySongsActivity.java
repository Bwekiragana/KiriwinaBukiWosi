package com.kiriwina.bukiwosi;

import android.content.Intent;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import java.util.List;

public class CategorySongsActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category_songs);
        String category = getIntent().getStringExtra("category");
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(category);
        List<Song> songs = DataManager.getInstance().getSongsByCategory(category);
        ListView listView = findViewById(R.id.list_songs);
        SongListAdapter adapter = new SongListAdapter(this, songs);
        listView.setAdapter(adapter);
        TextView tvEmpty = findViewById(R.id.tv_empty);
        if (songs.isEmpty()) tvEmpty.setVisibility(android.view.View.VISIBLE);
        listView.setOnItemClickListener((parent, view, position, id) -> {
            Song song = (Song) adapter.getItem(position);
            Intent intent = new Intent(this, SongDetailActivity.class);
            intent.putExtra("song_num", song.num);
            startActivity(intent);
        });
    }
    @Override public boolean onSupportNavigateUp() { finish(); return true; }
}
