package com.kiriwina.bukiwosi;

import android.content.Intent;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import com.google.android.material.chip.Chip;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class SongDetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_song_detail);

        int songNum = getIntent().getIntExtra("song_num", 1);
        Song song = DataManager.getInstance().getSongByNum(songNum);
        if (song == null) { finish(); return; }

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Song " + song.num);

        TextView tvTitle = findViewById(R.id.tv_title);
        TextView tvAuthor = findViewById(R.id.tv_author);
        Chip chipCat = findViewById(R.id.chip_category);
        LinearLayout llVerses = findViewById(R.id.ll_verses);
        FloatingActionButton fab = findViewById(R.id.fab_present);

        tvTitle.setText(song.title);
        tvAuthor.setText(song.author);
        chipCat.setText(song.category);

        LayoutInflater inflater = LayoutInflater.from(this);

        // Add each verse
        for (int i = 0; i < song.verses.size(); i++) {
            View block = inflater.inflate(R.layout.item_verse_block, llVerses, false);
            TextView tvLabel = block.findViewById(R.id.tv_verse_label);
            TextView tvText = block.findViewById(R.id.tv_verse_text);
            tvLabel.setText("VERSE " + (i + 1));
            tvText.setText(song.verses.get(i));
            llVerses.addView(block);
        }

        // Add chorus if present
        if (song.chorus != null && !song.chorus.isEmpty()) {
            View block = inflater.inflate(R.layout.item_chorus_block, llVerses, false);
            TextView tvText = block.findViewById(R.id.tv_chorus_text);
            tvText.setText(song.chorus);
            llVerses.addView(block);
        }

        // Present button launches projection mode
        fab.setOnClickListener(v -> {
            Intent intent = new Intent(this, PresentationActivity.class);
            intent.putExtra("song_num", song.num);
            startActivity(intent);
        });
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}
