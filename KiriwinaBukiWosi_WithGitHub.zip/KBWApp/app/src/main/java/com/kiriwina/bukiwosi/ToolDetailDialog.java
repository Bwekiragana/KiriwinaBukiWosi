package com.kiriwina.bukiwosi;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;

public class ToolDetailDialog {
    private Context context;
    private String title, content;

    public ToolDetailDialog(Context context, String title, String content) {
        this.context = context;
        this.title = title;
        this.content = content;
    }

    public void show() {
        new AlertDialog.Builder(context, R.style.AlertDialogTheme)
            .setTitle(title)
            .setMessage(content)
            .setPositiveButton("Close", null)
            .show();
    }
}
