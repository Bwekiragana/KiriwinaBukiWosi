package com.kiriwina.bukiwosi;

import java.util.List;

public class Author {
    public String name;
    public String years;
    public String role;
    public String contribution;
    public String bio;
    public List<Integer> songNums;

    public String getInitials() {
        if (name == null || name.isEmpty()) return "?";
        String[] parts = name.trim().split("\\s+");
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < Math.min(2, parts.length); i++) {
            if (!parts[i].isEmpty()) sb.append(parts[i].charAt(0));
        }
        return sb.toString().toUpperCase();
    }
}
