package com.kiriwina.bukiwosi;

import android.content.Intent;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import androidx.fragment.app.Fragment;
import java.util.List;

public class AuthorsFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_authors, container, false);
        ListView listView = v.findViewById(R.id.list_authors);
        List<Author> authors = DataManager.getInstance().getAuthors();
        AuthorListAdapter adapter = new AuthorListAdapter(getContext(), authors);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener((parent, view, position, id) -> {
            Intent intent = new Intent(getActivity(), AuthorDetailActivity.class);
            intent.putExtra("author_index", position);
            startActivity(intent);
        });
        return v;
    }
}
