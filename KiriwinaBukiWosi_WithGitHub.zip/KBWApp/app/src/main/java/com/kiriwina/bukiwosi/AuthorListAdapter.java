package com.kiriwina.bukiwosi;

import android.content.Context;
import android.view.*;
import android.widget.*;
import java.util.List;

public class AuthorListAdapter extends BaseAdapter {
    private Context context;
    private List<Author> authors;

    public AuthorListAdapter(Context context, List<Author> authors) {
        this.context = context;
        this.authors = authors;
    }

    @Override public int getCount() { return authors.size(); }
    @Override public Object getItem(int pos) { return authors.get(pos); }
    @Override public long getItemId(int pos) { return pos; }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null)
            convertView = LayoutInflater.from(context).inflate(R.layout.item_author, parent, false);
        Author a = authors.get(position);
        TextView tvInitials = convertView.findViewById(R.id.tv_initials);
        TextView tvName = convertView.findViewById(R.id.tv_author_name);
        TextView tvRole = convertView.findViewById(R.id.tv_author_role);
        TextView tvYears = convertView.findViewById(R.id.tv_author_years);
        tvInitials.setText(a.getInitials());
        tvName.setText(a.name);
        tvRole.setText(a.role);
        tvYears.setText(a.years);
        return convertView;
    }
}
