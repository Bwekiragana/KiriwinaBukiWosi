package com.kiriwina.bukiwosi;

import android.content.Intent;
import android.os.Bundle;
import android.view.*;
import android.widget.TextView;
import androidx.fragment.app.Fragment;
import com.google.android.material.card.MaterialCardView;
import java.util.List;

public class HomeFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_home, container, false);
        DataManager dm = DataManager.getInstance();

        TextView tvSongs = v.findViewById(R.id.stat_songs);
        TextView tvAuthors = v.findViewById(R.id.stat_authors);
        TextView tvCats = v.findViewById(R.id.stat_categories);
        tvSongs.setText(String.valueOf(dm.getSongs().size()));
        tvAuthors.setText(String.valueOf(dm.getAuthors().size()));
        tvCats.setText(String.valueOf(dm.getCategories().size()));

        // Quick search card
        MaterialCardView cardSearch = v.findViewById(R.id.card_search);
        MaterialCardView cardAuthors = v.findViewById(R.id.card_authors);
        MaterialCardView cardCategories = v.findViewById(R.id.card_categories);
        MaterialCardView cardTools = v.findViewById(R.id.card_tools);

        cardSearch.setOnClickListener(x -> switchTab(R.id.nav_search));
        cardAuthors.setOnClickListener(x -> switchTab(R.id.nav_authors));
        cardCategories.setOnClickListener(x -> switchTab(R.id.nav_categories));
        cardTools.setOnClickListener(x -> switchTab(R.id.nav_tools));

        // Random song of the day
        List<Song> songs = dm.getSongs();
        if (!songs.isEmpty()) {
            Song daily = songs.get((int)(System.currentTimeMillis() / 86400000) % songs.size());
            TextView tvDaily = v.findViewById(R.id.daily_song_title);
            TextView tvDailyMeta = v.findViewById(R.id.daily_song_meta);
            tvDaily.setText(daily.title);
            tvDailyMeta.setText("Song " + daily.num + " • " + daily.author);
            MaterialCardView cardDaily = v.findViewById(R.id.card_daily);
            cardDaily.setOnClickListener(x -> {
                Intent intent = new Intent(getActivity(), SongDetailActivity.class);
                intent.putExtra("song_num", daily.num);
                startActivity(intent);
            });
        }

        return v;
    }

    private void switchTab(int tabId) {
        if (getActivity() != null) {
            BottomNavigationView nav = getActivity().findViewById(R.id.bottom_nav);
            nav.setSelectedItemId(tabId);
        }
    }
}
