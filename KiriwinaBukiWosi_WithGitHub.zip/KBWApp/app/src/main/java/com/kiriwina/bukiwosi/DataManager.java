package com.kiriwina.bukiwosi;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class DataManager {
    private static DataManager instance;
    private List<Song> songs = new ArrayList<>();
    private List<Author> authors = new ArrayList<>();

    private DataManager() {}

    public static DataManager getInstance() {
        if (instance == null) instance = new DataManager();
        return instance;
    }

    public void load(Context ctx) {
        if (!songs.isEmpty()) return;
        try {
            songs = parseSongs(loadJson(ctx, "songs.json"));
            authors = parseAuthors(loadJson(ctx, "authors.json"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String loadJson(Context ctx, String filename) throws Exception {
        InputStream is = ctx.getAssets().open(filename);
        int size = is.available();
        byte[] buf = new byte[size];
        is.read(buf);
        is.close();
        return new String(buf, StandardCharsets.UTF_8);
    }

    private List<Song> parseSongs(String json) throws Exception {
        List<Song> list = new ArrayList<>();
        JSONArray arr = new JSONArray(json);
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.getJSONObject(i);
            Song s = new Song();
            s.num = o.getInt("num");
            s.title = o.getString("title");
            s.author = o.getString("author");
            s.category = o.getString("category");
            s.verses = new ArrayList<>();
            JSONArray v = o.getJSONArray("verses");
            for (int j = 0; j < v.length(); j++) s.verses.add(v.getString(j));
            s.chorus = o.isNull("chorus") ? null : o.getString("chorus");
            list.add(s);
        }
        return list;
    }

    private List<Author> parseAuthors(String json) throws Exception {
        List<Author> list = new ArrayList<>();
        JSONArray arr = new JSONArray(json);
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.getJSONObject(i);
            Author a = new Author();
            a.name = o.getString("name");
            a.years = o.getString("years");
            a.role = o.getString("role");
            a.contribution = o.getString("contribution");
            a.bio = o.getString("bio");
            a.songNums = new ArrayList<>();
            JSONArray sn = o.getJSONArray("songNums");
            for (int j = 0; j < sn.length(); j++) a.songNums.add(sn.getInt(j));
            list.add(a);
        }
        return list;
    }

    public List<Song> getSongs() { return songs; }
    public List<Author> getAuthors() { return authors; }

    public Song getSongByNum(int num) {
        for (Song s : songs) if (s.num == num) return s;
        return null;
    }

    public List<Song> searchByNumber(String q) {
        List<Song> r = new ArrayList<>();
        try { int n = Integer.parseInt(q.trim()); for (Song s : songs) if (s.num == n) r.add(s); } catch (Exception ignored) {}
        return r;
    }

    public List<Song> searchByLyric(String q) {
        List<Song> r = new ArrayList<>();
        String lq = q.toLowerCase().trim();
        if (lq.isEmpty()) return r;
        for (Song s : songs) {
            boolean found = false;
            for (String v : s.verses) if (v.toLowerCase().contains(lq)) { found = true; break; }
            if (!found && s.chorus != null && s.chorus.toLowerCase().contains(lq)) found = true;
            if (found) r.add(s);
        }
        return r;
    }

    public List<Song> searchByAuthor(String q) {
        List<Song> r = new ArrayList<>();
        String lq = q.toLowerCase().trim();
        if (lq.isEmpty()) return r;
        for (Song s : songs) if (s.author.toLowerCase().contains(lq)) r.add(s);
        return r;
    }

    public List<Song> getSongsByCategory(String cat) {
        List<Song> r = new ArrayList<>();
        for (Song s : songs) if (s.category.equals(cat)) r.add(s);
        return r;
    }

    public List<String> getCategories() {
        List<String> cats = new ArrayList<>();
        for (Song s : songs) if (!cats.contains(s.category)) cats.add(s.category);
        return cats;
    }
}
