package com.kiriwina.bukiwosi;

import android.content.Intent;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import androidx.fragment.app.Fragment;
import java.util.List;

public class CategoriesFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_categories, container, false);
        ListView listView = v.findViewById(R.id.list_categories);
        DataManager dm = DataManager.getInstance();
        List<String> cats = dm.getCategories();

        String[] allCats = {"Praise","Worship","Prayer","Wedding","Funeral","Children","Christmas","Easter","Harvest","General"};

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getContext(), android.R.layout.simple_list_item_1, allCats) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                if (convertView == null)
                    convertView = LayoutInflater.from(getContext()).inflate(R.layout.item_category, parent, false);
                String cat = allCats[position];
                int count = dm.getSongsByCategory(cat).size();
                TextView tvName = convertView.findViewById(R.id.tv_cat_name);
                TextView tvCount = convertView.findViewById(R.id.tv_cat_count);
                tvName.setText(cat);
                tvCount.setText(String.valueOf(count));
                return convertView;
            }
        };

        listView.setAdapter(adapter);
        listView.setOnItemClickListener((parent, view, position, id) -> {
            String cat = allCats[position];
            Intent intent = new Intent(getActivity(), CategorySongsActivity.class);
            intent.putExtra("category", cat);
            startActivity(intent);
        });
        return v;
    }
}
