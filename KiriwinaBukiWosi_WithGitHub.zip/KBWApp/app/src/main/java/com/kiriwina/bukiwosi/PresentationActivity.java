package com.kiriwina.bukiwosi;

import android.os.Bundle;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class PresentationActivity extends AppCompatActivity {

    private Song song;
    private int currentSection = 0;
    private TextView tvSongNum, tvSongTitle, tvSectionLabel, tvLyrics;
    private LinearLayout llDots;
    private Button btnPrev, btnNext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Fully immersive
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        );
        setContentView(R.layout.activity_presentation);

        int songNum = getIntent().getIntExtra("song_num", 1);
        song = DataManager.getInstance().getSongByNum(songNum);
        if (song == null) { finish(); return; }

        tvSongNum = findViewById(R.id.tv_proj_num);
        tvSongTitle = findViewById(R.id.tv_proj_title);
        tvSectionLabel = findViewById(R.id.tv_proj_label);
        tvLyrics = findViewById(R.id.tv_proj_lyrics);
        llDots = findViewById(R.id.ll_dots);
        btnPrev = findViewById(R.id.btn_prev);
        btnNext = findViewById(R.id.btn_next);

        btnPrev.setOnClickListener(v -> { if (currentSection > 0) { currentSection--; render(); } });
        btnNext.setOnClickListener(v -> { if (currentSection < song.getSectionCount() - 1) { currentSection++; render(); } });

        // Swipe gestures
        findViewById(R.id.proj_root).setOnTouchListener(new View.OnTouchListener() {
            float x1 = 0;
            public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) { x1 = e.getX(); return true; }
                if (e.getAction() == MotionEvent.ACTION_UP) {
                    float dx = e.getX() - x1;
                    if (dx < -100 && currentSection < song.getSectionCount() - 1) { currentSection++; render(); }
                    else if (dx > 100 && currentSection > 0) { currentSection--; render(); }
                    return true;
                }
                return false;
            }
        });

        render();
    }

    private void render() {
        tvSongNum.setText("Song " + song.num);
        tvSongTitle.setText(song.title);
        tvSectionLabel.setText(song.getSectionLabel(currentSection));
        tvLyrics.setText(song.getSection(currentSection));

        btnPrev.setEnabled(currentSection > 0);
        btnNext.setEnabled(currentSection < song.getSectionCount() - 1);

        // Dots
        llDots.removeAllViews();
        for (int i = 0; i < song.getSectionCount(); i++) {
            View dot = new View(this);
            int size = (int)(getResources().getDisplayMetrics().density * 10);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(size, size);
            lp.setMargins(8, 0, 8, 0);
            dot.setLayoutParams(lp);
            dot.setBackgroundResource(i == currentSection ? R.drawable.dot_active : R.drawable.dot_inactive);
            llDots.addView(dot);
        }
    }

    @Override
    public void onBackPressed() { finish(); }
}
