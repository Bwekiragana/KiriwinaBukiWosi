package com.kiriwina.bukiwosi;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.*;
import android.view.inputmethod.EditorInfo;
import android.widget.*;
import androidx.fragment.app.Fragment;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.textfield.TextInputEditText;
import java.util.List;

public class SearchFragment extends Fragment {

    private TextInputEditText etSearch;
    private ChipGroup chipGroup;
    private ListView listView;
    private TextView tvEmpty;
    private String currentTab = "number";
    private SongListAdapter adapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_search, container, false);

        etSearch = v.findViewById(R.id.et_search);
        chipGroup = v.findViewById(R.id.chip_group);
        listView = v.findViewById(R.id.list_songs);
        tvEmpty = v.findViewById(R.id.tv_empty);

        adapter = new SongListAdapter(getContext(), DataManager.getInstance().getSongs());
        listView.setAdapter(adapter);

        Chip chipNum = v.findViewById(R.id.chip_number);
        Chip chipLyric = v.findViewById(R.id.chip_lyric);
        Chip chipAuthor = v.findViewById(R.id.chip_author);

        chipNum.setOnClickListener(x -> { currentTab = "number"; updateHint(); doSearch(); });
        chipLyric.setOnClickListener(x -> { currentTab = "lyric"; updateHint(); doSearch(); });
        chipAuthor.setOnClickListener(x -> { currentTab = "author"; updateHint(); doSearch(); });

        etSearch.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            public void onTextChanged(CharSequence s, int start, int before, int count) { doSearch(); }
            public void afterTextChanged(Editable s) {}
        });

        etSearch.setOnEditorActionListener((tv, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH) { doSearch(); return true; }
            return false;
        });

        listView.setOnItemClickListener((parent, view, position, id) -> {
            Song song = (Song) adapter.getItem(position);
            Intent intent = new Intent(getActivity(), SongDetailActivity.class);
            intent.putExtra("song_num", song.num);
            startActivity(intent);
        });

        doSearch();
        return v;
    }

    private void updateHint() {
        if (currentTab.equals("number")) etSearch.setHint("Enter song number...");
        else if (currentTab.equals("lyric")) etSearch.setHint("Enter words from a song...");
        else etSearch.setHint("Enter author name...");
    }

    private void doSearch() {
        String q = etSearch.getText() != null ? etSearch.getText().toString().trim() : "";
        DataManager dm = DataManager.getInstance();
        List<Song> results;
        if (q.isEmpty()) {
            results = dm.getSongs();
        } else if (currentTab.equals("number")) {
            results = dm.searchByNumber(q);
        } else if (currentTab.equals("lyric")) {
            results = dm.searchByLyric(q);
        } else {
            results = dm.searchByAuthor(q);
        }
        adapter.updateList(results);
        tvEmpty.setVisibility(results.isEmpty() ? View.VISIBLE : View.GONE);
        listView.setVisibility(results.isEmpty() ? View.GONE : View.VISIBLE);
    }
}
