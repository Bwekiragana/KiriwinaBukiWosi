package com.kiriwina.bukiwosi;

import android.os.Bundle;
import android.view.*;
import android.widget.*;
import androidx.fragment.app.Fragment;
import com.google.android.material.card.MaterialCardView;

public class ToolsFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_tools, container, false);

        MaterialCardView cardWedding = v.findViewById(R.id.card_wedding);
        MaterialCardView cardDispute = v.findViewById(R.id.card_dispute);

        cardWedding.setOnClickListener(x -> {
            showToolDetail("Wedding Vow Reading Guide",
                "1. The pastor opens with a prayer and welcomes the congregation and families of both the bride and groom.\n\n" +
                "2. The groom faces the bride and reads his vows aloud, slowly and clearly for all to hear.\n\n" +
                "3. The bride then faces the groom and reads her vows in the same manner.\n\n" +
                "4. The pastor confirms the vows and the couple exchanges rings as a sign of their commitment.\n\n" +
                "5. The congregation is invited to sing a wedding hymn together."
            );
        });

        cardDispute.setOnClickListener(x -> {
            showToolDetail("Dispute Resolution Steps",
                "1. Both parties are invited to speak with a church elder privately before any group meeting.\n\n" +
                "2. The elder listens to each side separately, without judgment, and prays with each person.\n\n" +
                "3. A meeting is arranged with both parties and two elders present as witnesses.\n\n" +
                "4. Each party speaks without interruption. The elders guide toward a peaceful resolution.\n\n" +
                "5. A prayer of reconciliation is offered and the outcome is recorded by the church secretary."
            );
        });

        return v;
    }

    private void showToolDetail(String title, String content) {
        ToolDetailDialog dialog = new ToolDetailDialog(getContext(), title, content);
        dialog.show();
    }
}
