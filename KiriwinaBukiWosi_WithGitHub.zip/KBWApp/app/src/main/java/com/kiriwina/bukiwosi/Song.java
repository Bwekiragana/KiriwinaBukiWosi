package com.kiriwina.bukiwosi;

import java.util.List;

public class Song {
    public int num;
    public String title;
    public String author;
    public String category;
    public List<String> verses;
    public String chorus;

    public int getSectionCount() {
        int count = verses != null ? verses.size() : 0;
        if (chorus != null && !chorus.isEmpty()) count++;
        return count;
    }

    public String getSection(int index) {
        if (verses == null) return "";
        if (index < verses.size()) return verses.get(index);
        return chorus;
    }

    public String getSectionLabel(int index) {
        if (verses == null) return "";
        if (index < verses.size()) {
            return "Verse " + (index + 1) + " of " + verses.size();
        }
        return "Chorus";
    }
}
